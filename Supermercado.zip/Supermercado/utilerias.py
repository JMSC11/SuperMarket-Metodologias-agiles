import os
from Producto import Producto
class archivo:
    ruta_archivo = "Productos.txt"

    @classmethod
    def add_Producto(cls, producto):
        with open(cls.ruta_archivo, "a", encoding="UTF8") as archivo:
            archivo.write(f"{producto.id},{producto.nombre},{producto.proveedor}\n")


    @classmethod
    def listar_productos(cls):
        with open(cls.ruta_archivo, "r", encoding = "utf8") as archivo:
            print("Catálogo de productos".center(50, "-"))
            print(archivo.read())


    @classmethod
    def eliminar(cls,id):
        # Leer el contenido del archivo y almacenarlo en una lista de diccionarios
        with open(cls.ruta_archivo, "r") as archivo:
            lineas = archivo.readlines()
            registros = [linea.strip().split(",") for linea in lineas]
            registros = [{"id": int(registro[0]), "nombre": registro[1], "proveedor": registro[2]} for registro in registros]
        
        # Buscar el diccionario que corresponde al ID que deseas eliminar
        indice_a_eliminar = None
        for i, registro in enumerate(registros):
            if registro["id"] == id:
                indice_a_eliminar = i
                break
        
        # Si se encontró el registro, eliminarlo de la lista
        if indice_a_eliminar is not None:
            del registros[indice_a_eliminar]
            print(f"Registro con ID {id} eliminado.")
        else:
            print(f"No se encontró ningún registro con ID {id}.")

        os.remove(cls.ruta_archivo)
        for registro in registros:
            producto = Producto(registro['id'], registro['nombre'], registro['proveedor'])
            cls.add_Producto(producto)


    @classmethod
    def genera_ID(cls):
        with open(cls.ruta_archivo, "r") as archivo:
            lineas = archivo.readlines()
            num_filas = len(lineas)
            return num_filas+1
